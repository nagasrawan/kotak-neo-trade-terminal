# Kotak Neo Trade Terminal

This is a full-stack trading terminal project built with React (frontend) and Node.js (backend), designed to work with the Kotak Neo API.
